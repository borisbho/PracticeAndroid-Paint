package com.example.borisho.androidpaint;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    private CanvasView myCanvas;
    private Button redButton, blueButton, greenButton,undo,fill;
    private Button clearButton, plusButton, minusButton;
    private Button saveButton;

    private static final int DOT_SIZE_INCREMENT = 5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
     }

    private void init(){
        redButton = (Button)findViewById(R.id.red_button);
        blueButton = (Button)findViewById(R.id.blue_button);
        greenButton = (Button)findViewById(R.id.green_button);
        clearButton = (Button)findViewById(R.id.clear_button);
        plusButton = (Button)findViewById(R.id.plus_button);
        minusButton = (Button)findViewById(R.id.minus_button);
        saveButton = (Button)findViewById(R.id.save_button);
        undo = (Button)findViewById(R.id.undo_button);
        fill = (Button)findViewById(R.id.fill_button);
        fill.setOnClickListener(this);

        undo.setOnClickListener(this);
        redButton.setOnClickListener(this);
        blueButton.setOnClickListener(this);
        greenButton.setOnClickListener(this);
        clearButton.setOnClickListener(this);
        plusButton.setOnClickListener(this);
        minusButton.setOnClickListener(this);
        saveButton.setOnClickListener(this);
        myCanvas = (CanvasView)findViewById(R.id.canvas_view);

    }
    @Override
    public void onClick(View v) {
        Button b = (Button)findViewById(v.getId());
        switch (v.getId()){
            case R.id.red_button:
                myCanvas.setmPenColor(Color.RED);
                break;
            case R.id.blue_button:
                myCanvas.setmPenColor(Color.BLUE);
                break;
            case R.id.green_button:
                myCanvas.setmPenColor(Color.GREEN);
                break;
            case R.id.clear_button:
                myCanvas.reset();
                break;
            case R.id.plus_button:
                myCanvas.changeDotSize(+DOT_SIZE_INCREMENT);
                 break;
            case R.id.minus_button:
                myCanvas.changeDotSize(-DOT_SIZE_INCREMENT);
                break;
               case R.id.undo_button:
                myCanvas.undo();
                break;
            case R.id.fill_button:
                myCanvas.setStyle();
                break;
            case R.id.save_button:
                save();
               break;


        }
    }
    public void save(){
        CanvasView dv;
        dv = new CanvasView(MainActivity.this);
        dv.setDrawingCacheEnabled(true);
        Bitmap bitmap = dv.getDrawingCache();
        String path = Environment.getExternalStorageDirectory().getAbsolutePath();
        File file = new File(path+File.separator+"name"+".png");
        Toast.makeText(getApplicationContext(), file.getAbsolutePath(),Toast.LENGTH_LONG).show();
        try
        {
            if(!file.exists())

            {
                file.createNewFile();
            }
            FileOutputStream ostream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 10, ostream);

            ostream.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

}
